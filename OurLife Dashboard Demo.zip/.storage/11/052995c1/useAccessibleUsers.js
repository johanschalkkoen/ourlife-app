import { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE, DEFAULT_PROFILE_PIC } from '../utils/helpers';

const useAccessibleUsers = (user, setUserProfiles) => {
  const [targetUsers, setTargetUsers] = useState([]);
  const [showTargetUsers, setShowTargetUsers] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user?.username) {
      console.error('useAccessibleUsers: No username provided');
      setError('User not logged in');
      setTargetUsers([]);
      setUserProfiles({ [user?.username || 'unknown']: DEFAULT_PROFILE_PIC });
      return;
    }

    console.log('useAccessibleUsers: Fetching access list for viewer:', user.username);
    
    axios.get(`${API_BASE}/get-access`, { 
      params: { viewer: user.username, adminUsername: user.username }
    })
      .then(({ data }) => {
        console.log('useAccessibleUsers: API response:', data);
        if (data.success && Array.isArray(data.accessList)) {
          const users = data.accessList
            .filter(a => a.viewer === user.username)
            .map(a => a.target);
            
          console.log('useAccessibleUsers: targetUsers set to:', users);
          setTargetUsers(users);
          setError('');
          
          Promise.all(users.concat(user.username).map(u =>
            axios.get(`${API_BASE}/profile-pictures?username=${u}`)
              .then(({ data }) => {
                console.log(`useAccessibleUsers: Profile pic for ${u}:`, data.profilePicUrl);
                return [u, data.profilePicUrl || DEFAULT_PROFILE_PIC];
              })
              .catch(err => {
                console.error(`useAccessibleUsers: Error fetching profile pic for ${u}:`, err);
                return [u, DEFAULT_PROFILE_PIC];
              })
          )).then(results => {
            const profiles = Object.fromEntries(results);
            console.log('useAccessibleUsers: userProfiles set to:', profiles);
            setUserProfiles(profiles);
          });
        } else {
          console.error('useAccessibleUsers: Invalid API response:', data.message);
          setTargetUsers([]);
          setError(data.message || 'Failed to fetch access list.');
          setUserProfiles({ [user.username]: user.profilePicUrl || DEFAULT_PROFILE_PIC });
        }
      })
      .catch(err => {
        console.error('useAccessibleUsers: Error fetching access list:', err.response?.data || err);
        setError(err.response?.data?.message || 'Error fetching access list. Check server.');
        setUserProfiles({ [user.username]: user.profilePicUrl || DEFAULT_PROFILE_PIC });
      });
  }, [user?.username]);

  return { targetUsers, showTargetUsers, setShowTargetUsers, error };
};

export default useAccessibleUsers;