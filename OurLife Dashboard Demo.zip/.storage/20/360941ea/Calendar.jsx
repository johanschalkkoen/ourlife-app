import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { API_BASE, DEFAULT_PROFILE_PIC, DEFAULT_EVENT_COLOR, getCurrentDateTime, formatDateTime, capitalize } from '../utils/helpers';
import { Input, Button, Select, ProfilePic } from './ui/FormElements';
import useAccessibleUsers from '../hooks/useAccessibleUsers';
import { MONTHS } from '../utils/helpers';

// Note: FullCalendar would be imported using CDN in index.html or using npm package
// This component assumes FullCalendar is available as a global variable

const Calendar = ({ user, setPage, onLogout }) => {
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({
    title: '',
    date: getCurrentDateTime(),
    financial: false,
    amount: '',
    category: 'income'
  });
  const [selectedMonth, setSelectedMonth] = useState('07');
  const [showAddEventForm, setShowAddEventForm] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [userProfiles, setUserProfiles] = useState({
    [user.username]: user.profilePicUrl || DEFAULT_PROFILE_PIC
  });
  
  const {
    targetUsers,
    showTargetUsers,
    setShowTargetUsers,
    error
  } = useAccessibleUsers(user, profiles => setUserProfiles(profiles));
  
  const calendarRef = useRef(null);
  const fullCalendarInstance = useRef(null);
  
  const fetchEvents = () => {
    console.log('Calendar: fetchEvents called, showTargetUsers:', showTargetUsers, 'targetUsers:', targetUsers);
    const usersToFetch = [user.username, ...(showTargetUsers ? targetUsers : [])];
    console.log('Calendar: Fetching data for users:', usersToFetch);
    
    Promise.all(usersToFetch.map(u => 
      axios.get(`${API_BASE}/calendar`, { params: { user: u } })
        .then(({ data }) => {
          console.log(`Calendar: Data fetched for ${u}:`, data);
          return data.map(e => ({
            id: e.id,
            title: e.title,
            start: e.date,
            user: e.user,
            financial: e.financial,
            type: e.type,
            amount: e.amount,
            eventColor: e.eventColor || DEFAULT_EVENT_COLOR
          }));
        })
        .catch(err => {
          console.error(`Calendar: Error fetching data for ${u}:`, err);
          return [];
        })
    )).then(results => {
      const flatEvents = results.flat();
      console.log('Calendar: Combined events:', flatEvents);
      setEvents(flatEvents);
    });
  };
  
  const handleAddEvent = async () => {
    if (!form.title || !form.date) return alert('Event title and date are required!');
    
    try {
      const eventData = {
        user: user.username,
        title: form.title,
        date: form.date,
        financial: form.financial,
        type: form.financial ? form.category : undefined,
        amount: form.financial ? parseFloat(form.amount) : undefined,
        eventColor: user.eventColor
      };
      
      await Promise.all([
        axios.post(`${API_BASE}/calendar`, eventData),
        form.financial && axios.post(`${API_BASE}/financial`, {
          user: user.username,
          description: form.title,
          amount: parseFloat(form.amount),
          type: form.category,
          date: form.date
        })
      ].filter(Boolean));
      
      fetchEvents();
      setForm({
        title: '',
        date: getCurrentDateTime(),
        financial: false,
        amount: '',
        category: 'income'
      });
      setShowAddEventForm(false);
    } catch (err) {
      alert('Failed to add event.');
      console.error('Calendar: Error adding event:', err);
    }
  };
  
  const handleDeleteEvent = id => 
    axios.delete(`${API_BASE}/calendar/${id}`)
      .then(() => {
        fetchEvents();
        setShowModal(false);
        setTimeout(() => setSelectedEvent(null), 300);
      })
      .catch(err => {
        alert('Failed to delete event.');
        console.error('Calendar: Error deleting event:', err);
      });
  
  const toggleButtonLabel = targetUsers.length === 1
    ? `Show/Hide ${capitalize(targetUsers[0])}'s Data`
    : `Show/Hide Accessible Users' Data`;
  
  useEffect(() => {
    fetchEvents();
    const calendarEl = calendarRef.current;
    
    if (calendarEl && !fullCalendarInstance.current && window.FullCalendar) {
      fullCalendarInstance.current = new window.FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        initialDate: `2025-${selectedMonth}-01`,
        editable: true,
        selectable: true,
        events: events.filter(e => [user.username, ...(showTargetUsers ? targetUsers : [])].includes(e.user)),
        eventContent: ({ event }) => {
          const eventEl = document.createElement('div');
          eventEl.className = 'fc-event-main';
          eventEl.style.backgroundColor = event.extendedProps.eventColor;
          eventEl.style.opacity = '0.8';
          
          const imgEl = document.createElement('img');
          imgEl.src = userProfiles[event.extendedProps.user] || DEFAULT_PROFILE_PIC;
          imgEl.alt = event.extendedProps.user;
          imgEl.className = 'event-profile-pic';
          
          const titleSpan = document.createElement('span');
          titleSpan.className = 'fc-event-title';
          titleSpan.textContent = event.title;
          
          const userSpan = document.createElement('span');
          userSpan.className = 'fc-event-user';
          userSpan.textContent = event.extendedProps.user;
          
          const eventPicContainer = document.createElement('div');
          eventPicContainer.className = 'event-profile-pic-container';
          eventPicContainer.appendChild(imgEl);
          
          eventEl.appendChild(eventPicContainer);
          eventEl.appendChild(titleSpan);
          eventEl.appendChild(userSpan);
          
          return { domNodes: [eventEl] };
        },
        eventClick: ({ event }) => {
          setSelectedEvent({
            id: event.id,
            title: event.title,
            date: event.start.toISOString().slice(0, 19),
            user: event.extendedProps.user,
            financial: event.extendedProps.financial,
            type: event.extendedProps.type,
            amount: event.extendedProps.amount,
            profilePicUrl: userProfiles[event.extendedProps.user] || DEFAULT_PROFILE_PIC,
            eventColor: event.extendedProps.eventColor
          });
          setShowModal(true);
        },
        select: () => {
          setForm({ ...form, date: getCurrentDateTime() });
          setShowAddEventForm(true);
        }
      });
      
      fullCalendarInstance.current.render();
    }
    
    return () => {
      if (fullCalendarInstance.current) {
        fullCalendarInstance.current.destroy();
        fullCalendarInstance.current = null;
      }
    };
  }, [userProfiles]);
  
  useEffect(() => {
    if (fullCalendarInstance.current) {
      fullCalendarInstance.current.gotoDate(`2025-${selectedMonth}-01`);
    }
  }, [selectedMonth]);
  
  useEffect(() => {
    if (fullCalendarInstance.current) {
      fullCalendarInstance.current.setOption('events', 
        events.filter(e => [user.username, ...(showTargetUsers ? targetUsers : [])].includes(e.user))
      );
    }
  }, [events, showTargetUsers]);
  
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex justify-between mb-6">
        <Button className="btn-secondary" onClick={() => setPage('menu')}>
          Back to Menu
        </Button>
        <Button className="btn-danger" onClick={onLogout}>
          Sign Out
        </Button>
      </div>
      <div className="card p-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-white flex items-center gap-3">
            <ProfilePic src={user.profilePicUrl} username={user.username} />
            <span>Calendar</span>
          </h1>
          <div className="flex space-x-3">
            <Select
              options={MONTHS.map(m => ({ ...m, label: `${m.label} 2025` }))}
              value={selectedMonth}
              onChange={e => setSelectedMonth(e.target.value)}
            />
            <Button
              className="btn-info"
              onClick={() => setShowAddEventForm(!showAddEventForm)}
            >
              {showAddEventForm ? 'Hide Form' : 'Add Event'}
            </Button>
          </div>
        </div>
        
        {error && <p className="error-message">{error}</p>}
        
        {targetUsers.length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-medium text-white mb-3">View Data:</h3>
            <div className="flex flex-wrap gap-2">
              <button
                className={`toggle-button ${showTargetUsers ? 'active' : 'inactive'}`}
                onClick={() => setShowTargetUsers(!showTargetUsers)}
              >
                {toggleButtonLabel}
              </button>
            </div>
          </div>
        )}
        
        {showAddEventForm && (
          <div className="card p-6 mb-6 space-y-4">
            <h2 className="text-xl font-semibold text-white">Add Calendar Event</h2>
            <Input
              placeholder="Event Title"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
            />
            <Input
              type="datetime-local"
              value={form.date}
              onChange={e => setForm({ ...form, date: e.target.value })}
              step="1"
            />
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isFinancial"
                checked={form.financial}
                onChange={e => setForm({ ...form, financial: e.target.checked })}
                className="form-checkbox h-5 w-5 text-teal-500 rounded"
              />
              <label htmlFor="isFinancial" className="text-white">Financial Event?</label>
            </div>
            {form.financial && (
              <div className="space-y-4">
                <Input
                  type="number"
                  placeholder="Amount (in ZAR)"
                  value={form.amount}
                  onChange={e => setForm({ ...form, amount: e.target.value })}
                />
                <Select
                  value={form.category}
                  onChange={e => setForm({ ...form, category: e.target.value })}
                  options={[
                    { value: 'income', label: 'Income' },
                    { value: 'expense', label: 'Expense' }
                  ]}
                />
              </div>
            )}
            <Button onClick={handleAddEvent}>Add Event</Button>
          </div>
        )}
        
        <div id="calendar" ref={calendarRef} className="text-white"></div>
        
        {showModal && selectedEvent && (
          <div
            className="fixed inset-0 flex items-center justify-center bg-black/50 z-50"
            onClick={() => {
              setShowModal(false);
              setTimeout(() => setSelectedEvent(null), 300);
            }}
          >
            <div
              className={`modal card p-8 max-w-md w-full mx-4 ${showModal ? 'show' : ''}`}
              style={{ backgroundColor: selectedEvent.eventColor, opacity: 0.8 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-white">Event Details</h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="event-profile-pic-container !w-10 !h-10">
                    <img
                      src={selectedEvent.profilePicUrl}
                      alt={selectedEvent.user}
                      className="event-profile-pic"
                    />
                  </div>
                  <span className="text-lg font-semibold text-white">{selectedEvent.title}</span>
                </div>
                <p className="text-white"><strong>Date:</strong> {formatDateTime(selectedEvent.date)}</p>
                <p className="text-white"><strong>User:</strong> {selectedEvent.user}</p>
                {selectedEvent.financial ? (
                  <>
                    <p className="text-white"><strong>Type:</strong> {selectedEvent.type}</p>
                    <p className="text-white"><strong>Amount:</strong> R{selectedEvent.amount.toFixed(2)}</p>
                  </>
                ) : <p className="text-white">Non-financial event</p>}
                {selectedEvent.user === user.username && (
                  <Button className="btn-danger" onClick={() => handleDeleteEvent(selectedEvent.id)}>
                    Delete Event
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Calendar;