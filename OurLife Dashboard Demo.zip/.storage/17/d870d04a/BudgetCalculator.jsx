import React, { useState } from 'react';
import { formatAmount } from '../utils/helpers';
import { Input, Button, ProfilePic } from './ui/FormElements';

const BudgetCalculator = ({ user, setPage, onLogout }) => {
  const [budget, setBudget] = useState({
    income: '',
    expenses: [
      { category: 'Rent/Mortgage', amount: '' },
      { category: 'Utilities', amount: '' },
      { category: 'Groceries', amount: '' },
      { category: 'Transport', amount: '' },
      { category: 'Other', amount: '' }
    ]
  });
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [remainingBudget, setRemainingBudget] = useState(0);
  const [message, setMessage] = useState('');

  const handleIncomeChange = (e) => {
    const income = e.target.value;
    setBudget({ ...budget, income });
    calculateBudget(income, budget.expenses);
  };

  const handleExpenseChange = (index, value) => {
    const newExpenses = [...budget.expenses];
    newExpenses[index].amount = value;
    setBudget({ ...budget, expenses: newExpenses });
    calculateBudget(budget.income, newExpenses);
  };

  const calculateBudget = (income, expenses) => {
    const total = expenses.reduce((sum, exp) => sum + (parseFloat(exp.amount) || 0), 0);
    setTotalExpenses(total);
    setRemainingBudget((parseFloat(income) || 0) - total);
    setMessage('');
  };

  const handleSaveBudget = () => {
    if (!budget.income || budget.expenses.some(exp => !exp.amount)) {
      setMessage('Please fill in all fields.');
      return;
    }
    setMessage('Budget saved successfully!');
    // Here you would typically save to an API or localStorage
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex justify-between mb-6">
        <Button className="btn-secondary" onClick={() => setPage('menu')}>
          Back to Menu
        </Button>
        <Button className="btn-danger" onClick={onLogout}>
          Sign Out
        </Button>
      </div>
      <div className="card p-8">
        <h1 className="text-2xl font-semibold text-white mb-6 flex items-center gap-3">
          <ProfilePic src={user.profilePicUrl} username={user.username} />
          <span>Budget Calculator</span>
        </h1>
        
        {message && (
          <p className={`text-center text-sm ${message.includes('success') ? 'text-green-400' : 'text-red-400'} mb-6`}>
            {message}
          </p>
        )}
        
        <div className="space-y-6">
          <Input
            label="Monthly Income (ZAR)"
            type="number"
            placeholder="Enter your total monthly income"
            value={budget.income}
            onChange={handleIncomeChange}
          />
          
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-white">Expenses</h2>
            {budget.expenses.map((expense, index) => (
              <div key={index} className="flex items-center gap-4">
                <Input
                  label={expense.category}
                  type="number"
                  placeholder={`Enter ${expense.category.toLowerCase()} amount`}
                  value={expense.amount}
                  onChange={e => handleExpenseChange(index, e.target.value)}
                />
              </div>
            ))}
          </div>
          
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-2">Budget Summary</h2>
            <p className="text-white">Total Income: {formatAmount(budget.income || 0)}</p>
            <p className="text-white">Total Expenses: {formatAmount(totalExpenses)}</p>
            <p className={`text-2xl font-bold ${remainingBudget >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              Remaining Budget: {formatAmount(remainingBudget)}
            </p>
          </div>
          
          <Button onClick={handleSaveBudget}>Save Budget</Button>
        </div>
      </div>
    </div>
  );
};

export default BudgetCalculator;