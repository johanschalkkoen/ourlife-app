import React, { useState } from 'react';
import axios from 'axios';
import { API_BASE, DEFAULT_PROFILE_PIC, DEFAULT_EVENT_COLOR } from '../../utils/helpers';
import { Input, Button } from '../ui/FormElements';

const Login = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  
  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };
  
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.post(`${API_BASE}/login`, credentials);
      
      if (data.success) {
        const { data: profile } = await axios
          .get(`${API_BASE}/profile-pictures?username=${credentials.username}`)
          .catch(() => ({
            data: { 
              profilePicUrl: DEFAULT_PROFILE_PIC, 
              eventColor: DEFAULT_EVENT_COLOR, 
              gender: '' 
            }
          }));
        
        onLogin({
          username: credentials.username,
          profilePicUrl: profile.profilePicUrl || DEFAULT_PROFILE_PIC,
          eventColor: profile.eventColor || DEFAULT_EVENT_COLOR,
          email: profile.email || '',
          phone: profile.phone || '',
          address: profile.address || '',
          isAdmin: profile.isAdmin || false,
          gender: profile.gender || ''
        });
      } else {
        setError(data.message || 'Login failed.');
      }
    } catch (err) {
      setError('Error during login. Check server.');
      console.error('Login error:', err);
    }
  };
  
  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="card p-8 w-full max-w-md">
        <h1 className="text-2xl font-semibold text-white mb-6 text-center">Sign In</h1>
        <form onSubmit={handleLogin} className="space-y-4">
          <Input
            name="username"
            placeholder="Username"
            value={credentials.username}
            onChange={handleChange}
          />
          <Input
            type="password"
            name="password"
            placeholder="Password"
            value={credentials.password}
            onChange={handleChange}
          />
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          <Button type="submit" className="w-full">Sign In</Button>
        </form>
      </div>
    </div>
  );
};

export default Login;