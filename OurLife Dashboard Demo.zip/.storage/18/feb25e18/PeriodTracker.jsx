import React, { useState } from 'react';
import { formatDate } from '../utils/helpers';
import { Input, Button, ProfilePic } from './ui/FormElements';

const PeriodTracker = ({ user, setPage, onLogout }) => {
  const [cycles, setCycles] = useState([]);
  const [form, setForm] = useState({
    startDate: formatDate(new Date()),
    endDate: '',
    cycleLength: '28',
    symptoms: ''
  });
  const [message, setMessage] = useState('');
  const [predictions, setPredictions] = useState({
    nextPeriod: '',
    fertileDays: ''
  });

  const calculatePredictions = (cycles) => {
    if (!cycles.length) return { nextPeriod: '', fertileDays: '' };
    
    const lastCycle = cycles[cycles.length - 1];
    if (!lastCycle.startDate) return { nextPeriod: '', fertileDays: '' };
    
    const start = new Date(lastCycle.startDate);
    const avgCycleLength = parseInt(lastCycle.cycleLength) || 28;
    
    const nextPeriod = new Date(start);
    nextPeriod.setDate(start.getDate() + avgCycleLength);
    
    const fertileStart = new Date(start);
    fertileStart.setDate(start.getDate() + avgCycleLength - 14 - 5); // Approx ovulation -5 days
    
    const fertileEnd = new Date(fertileStart);
    fertileEnd.setDate(fertileStart.getDate() + 6);
    
    return {
      nextPeriod: formatDate(nextPeriod),
      fertileDays: `${formatDate(fertileStart)} to ${formatDate(fertileEnd)}`
    };
  };

  const handleAddCycle = () => {
    if (!form.startDate || !form.cycleLength) {
      setMessage('Start date and cycle length are required.');
      return;
    }
    
    const newCycle = {
      id: Date.now(),
      startDate: form.startDate,
      endDate: form.endDate || '',
      cycleLength: form.cycleLength,
      symptoms: form.symptoms || ''
    };
    
    const updatedCycles = [...cycles, newCycle];
    setCycles(updatedCycles);
    setPredictions(calculatePredictions(updatedCycles));
    
    setForm({
      startDate: formatDate(new Date()),
      endDate: '',
      cycleLength: '28',
      symptoms: ''
    });
    
    setMessage('Cycle added successfully!');
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex justify-between mb-6">
        <Button className="btn-secondary" onClick={() => setPage('menu')}>
          Back to Menu
        </Button>
        <Button className="btn-danger" onClick={onLogout}>
          Sign Out
        </Button>
      </div>
      <div className="card p-8">
        <h1 className="text-2xl font-semibold text-white mb-6 flex items-center gap-3">
          <ProfilePic src={user.profilePicUrl} username={user.username} />
          <span>Period Tracker</span>
        </h1>
        
        {message && (
          <p className={`text-center text-sm ${message.includes('success') ? 'text-green-400' : 'text-red-400'} mb-6`}>
            {message}
          </p>
        )}
        
        <div className="space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-white">Log New Cycle</h2>
            <Input
              label="Start Date"
              type="date"
              name="startDate"
              value={form.startDate}
              onChange={e => setForm({ ...form, startDate: e.target.value })}
            />
            <Input
              label="End Date (Optional)"
              type="date"
              name="endDate"
              value={form.endDate}
              onChange={e => setForm({ ...form, endDate: e.target.value })}
            />
            <Input
              label="Cycle Length (days)"
              type="number"
              name="cycleLength"
              value={form.cycleLength}
              onChange={e => setForm({ ...form, cycleLength: e.target.value })}
              placeholder="e.g., 28"
            />
            <div>
              <label className="form-label">Symptoms (Optional)</label>
              <textarea
                name="symptoms"
                value={form.symptoms}
                onChange={e => setForm({ ...form, symptoms: e.target.value })}
                placeholder="e.g., Cramps, Mood swings"
                rows="3"
                className="form-input"
              ></textarea>
            </div>
            <Button onClick={handleAddCycle}>Add Cycle</Button>
          </div>
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-2">Cycle Summary</h2>
            {cycles.length > 0 ? (
              <>
                <p className="text-white">Last Cycle Start: {formatDate(cycles[cycles.length - 1].startDate)}</p>
                <p className="text-white">Predicted Next Period: {predictions.nextPeriod || 'N/A'}</p>
                <p className="text-white">Fertile Days: {predictions.fertileDays || 'N/A'}</p>
                <h3 className="text-lg font-semibold text-white mt-4">Cycle History</h3>
                <div className="space-y-3 mt-2">
                  {cycles.map(cycle => (
                    <div key={cycle.id} className="p-4 card">
                      <p className="text-white">Start: {formatDate(cycle.startDate)}</p>
                      {cycle.endDate && <p className="text-white">End: {formatDate(cycle.endDate)}</p>}
                      <p className="text-white">Cycle Length: {cycle.cycleLength} days</p>
                      {cycle.symptoms && <p className="text-white">Symptoms: {cycle.symptoms}</p>}
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-gray-300">No cycles logged yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PeriodTracker;