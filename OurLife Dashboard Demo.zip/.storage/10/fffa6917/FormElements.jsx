import React from 'react';

export const Input = ({ label, className = '', ...props }) => (
  <div>
    {label && <label className="form-label">{label}</label>}
    <input className={`form-input ${className}`} {...props} />
  </div>
);

export const Select = ({ label, options, className = '', ...props }) => (
  <div>
    {label && <label className="form-label">{label}</label>}
    <select className={`form-select ${className}`} {...props}>
      {options.map(opt => (
        <option key={opt.value} value={opt.value}>
          {opt.label || opt.value}
        </option>
      ))}
    </select>
  </div>
);

export const Button = ({ children, className = 'btn-primary', ...props }) => (
  <button className={`btn ${className}`} {...props}>
    {children}
  </button>
);

export const ProfilePic = ({
  src,
  username,
  size = '56px',
  border = '2px solid #2dd4bf',
  showUsername = true
}) => (
  <div className="flex flex-col items-center">
    <div
      className="profile-pic-container"
      style={{ width: size, height: size, border }}
    >
      <img
        src={src || 'https://placehold.co/50x50/808080/FFFFFF?text=U'}
        alt={username}
        className="profile-pic"
      />
    </div>
    {showUsername && <span className="text-sm text-gray-300 mt-2">{username}</span>}
  </div>
);