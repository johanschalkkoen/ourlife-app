// Constants
export const API_BASE = 'https://ourlife.work.gd:8443/api';
export const DEFAULT_PROFILE_PIC = 'https://placehold.co/50x50/808080/FFFFFF?text=U';
export const DEFAULT_EVENT_COLOR = '#2dd4bf';
export const MONTHS = [
  { value: '01', label: 'January' },
  { value: '02', label: 'February' },
  { value: '03', label: 'March' },
  { value: '04', label: 'April' },
  { value: '05', label: 'May' },
  { value: '06', label: 'June' },
  { value: '07', label: 'July' },
  { value: '08', label: 'August' },
  { value: '09', label: 'September' },
  { value: '10', label: 'October' },
  { value: '11', label: 'November' },
  { value: '12', label: 'December' }
];
export const CURRENCY_CONFIG = {
  USD: { symbol: '$', rate: 1 },
  EUR: { symbol: '€', rate: 0.85 },
  ZAR: { symbol: 'R', rate: 18.5 }
};

// Utility functions
export const capitalize = (str) => str ? str.charAt(0).toUpperCase() + str.slice(1) : '';

export const getCurrentDateTime = () => {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  return now.toISOString().slice(0, 19);
};

export const formatDateTime = (date) => 
  new Date(date).toLocaleString('en-ZA', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).replace(/,/, '');

export const formatAmount = (amount) => 
  `${CURRENCY_CONFIG.ZAR.symbol}${parseFloat(amount).toFixed(2)}`;

export const formatDate = (date) => 
  new Date(date).toISOString().slice(0, 10);

// Local Storage helpers
export const getStoredUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

export const storeUser = (user) => {
  localStorage.setItem('user', JSON.stringify(user));
};

export const clearStoredUser = () => {
  localStorage.removeItem('user');
};