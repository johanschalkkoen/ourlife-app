import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Login from './components/auth/Login';
import Menu from './components/Menu';
import Financial from './components/Financial';
import BudgetCalculator from './components/BudgetCalculator';
import PeriodTracker from './components/PeriodTracker';
import Calendar from './components/Calendar';
import ProfileSettings from './components/ProfileSettings';
import Admin from './components/Admin';
import { getStoredUser, storeUser, clearStoredUser } from './utils/helpers';

function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('login');
  
  // Load external scripts needed for components
  useEffect(() => {
    const loadExternalScripts = async () => {
      try {
        // Add FullCalendar script
        const fullCalendarScript = document.createElement('script');
        fullCalendarScript.src = 'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js';
        fullCalendarScript.async = true;
        document.body.appendChild(fullCalendarScript);
        
        // Add Compressor.js script
        const compressorScript = document.createElement('script');
        compressorScript.src = 'https://cdn.jsdelivr.net/npm/compressorjs@1.2.1/dist/compressor.min.js';
        compressorScript.async = true;
        document.body.appendChild(compressorScript);
        
        // Add axios script
        const axiosScript = document.createElement('script');
        axiosScript.src = 'https://cdn.jsdelivr.net/npm/axios@1.4.0/dist/axios.min.js';
        axiosScript.async = true;
        document.body.appendChild(axiosScript);
      } catch (error) {
        console.error('Error loading external scripts:', error);
      }
    };
    
    loadExternalScripts();
  }, []);

  const handleLogin = userData => {
    setUser(userData);
    setPage('menu');
    storeUser(userData);
  };
  
  const handleLogout = () => {
    console.log('Logging out, clearing user');
    setUser(null);
    setPage('login');
    clearStoredUser();
  };
  
  // Check for stored user on initial load
  useEffect(() => {
    const storedUser = getStoredUser();
    if (storedUser) {
      console.log('Restoring user from localStorage:', storedUser);
      setUser(storedUser);
      setPage('menu');
    }
  }, []);

  // Route to appropriate component based on page state
  const renderPage = () => {
    if (!user && page !== 'login') return <Login onLogin={handleLogin} />;
    
    switch (page) {
      case 'login':
        return <Login onLogin={handleLogin} />;
      case 'menu':
        return <Menu user={user} setPage={setPage} onLogout={handleLogout} />;
      case 'financial':
        return <Financial user={user} setPage={setPage} onLogout={handleLogout} />;
      case 'budgetCalculator':
        return <BudgetCalculator user={user} setPage={setPage} onLogout={handleLogout} />;
      case 'periodTracker':
        return user.gender === 'Female' ? 
          <PeriodTracker user={user} setPage={setPage} onLogout={handleLogout} /> : 
          <Menu user={user} setPage={setPage} onLogout={handleLogout} />;
      case 'calendar':
        return <Calendar user={user} setPage={setPage} onLogout={handleLogout} />;
      case 'profileSettings':
        return <ProfileSettings user={user} setPage={setPage} onLogout={handleLogout} setUser={setUser} />;
      case 'admin':
        return user.isAdmin ? 
          <Admin user={user} setPage={setPage} onLogout={handleLogout} /> : 
          <Menu user={user} setPage={setPage} onLogout={handleLogout} />;
      default:
        return <Menu user={user} setPage={setPage} onLogout={handleLogout} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {renderPage()}
    </div>
  );
}

export default App;