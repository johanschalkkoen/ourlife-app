import React from 'react';
import { capitalize } from '../utils/helpers';
import { Button, ProfilePic } from './ui/FormElements';

const Menu = ({ user, setPage, onLogout }) => {
  const menuItems = [
    'financial',
    'budgetCalculator',
    ...(user.gender === 'Female' ? ['periodTracker'] : []),
    'calendar',
    'profileSettings',
    ...(user.isAdmin ? ['admin'] : [])
  ];

  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="card p-8 w-full max-w-md">
        <h1 className="text-2xl font-semibold text-white mb-6 text-center flex items-center justify-center gap-3">
          <ProfilePic src={user.profilePicUrl} username={user.username} />
          <span>Welcome, {capitalize(user.username)}!</span>
        </h1>
        <div className="space-y-3">
          {menuItems.map(page => (
            <Button 
              key={page} 
              className="w-full"
              onClick={() => setPage(page)}
            >
              {capitalize(page)}
            </Button>
          ))}
          <Button 
            className="w-full btn-danger" 
            onClick={onLogout}
          >
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Menu;