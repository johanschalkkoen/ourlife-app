import React, { useState } from 'react';
import axios from 'axios';
import { API_BASE, DEFAULT_PROFILE_PIC } from '../utils/helpers';
import { Input, Button, Select, ProfilePic } from './ui/FormElements';

const ProfileSettings = ({ user, setPage, onLogout, setUser }) => {
  const [form, setForm] = useState({
    profilePicUrl: user.profilePicUrl || '',
    email: user.email || '',
    phone: user.phone || '',
    address: user.address || '',
    eventColor: user.eventColor || DEFAULT_PROFILE_PIC,
    gender: user.gender || '',
    currentPassword: '',
    newPassword: '',
    confirmNewPassword: ''
  });
  
  const [selectedFile, setSelectedFile] = useState(null);
  const [message, setMessage] = useState('');
  const [passwordMessage, setPasswordMessage] = useState('');
  
  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) {
      setSelectedFile(null);
      setForm({ ...form, profilePicUrl: user.profilePicUrl || DEFAULT_PROFILE_PIC });
      return;
    }
    
    if (!file.type.startsWith('image/')) {
      setMessage('Please select a valid image file (e.g., PNG, JPEG).');
      setSelectedFile(null);
      setForm({ ...form, profilePicUrl: user.profilePicUrl || DEFAULT_PROFILE_PIC });
      return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
      setMessage('Image size must be less than 5MB.');
      setSelectedFile(null);
      setForm({ ...form, profilePicUrl: user.profilePicUrl || DEFAULT_PROFILE_PIC });
      return;
    }
    
    // Simple file reading without compression
    setSelectedFile(file);
    setMessage('');
    const reader = new FileReader();
    reader.onloadend = () => setForm({ ...form, profilePicUrl: reader.result });
    reader.readAsDataURL(file);
  };
  
  const handleSaveProfile = async () => {
    setMessage('Saving...');
    try {
      const urlToSave = selectedFile ? await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(selectedFile);
      }) : form.profilePicUrl || DEFAULT_PROFILE_PIC;
      
      if (urlToSave !== DEFAULT_PROFILE_PIC && !urlToSave.match(/^data:image\/(png|jpeg|jpg|gif);base64,/)) {
        setMessage('Invalid image format. Please upload a valid image.');
        return;
      }
      
      const { data } = await axios.post(`${API_BASE}/profile-pictures`, {
        username: user.username,
        profilePicUrl: urlToSave,
        email: form.email,
        phone: form.phone,
        address: form.address,
        eventColor: form.eventColor,
        gender: form.gender
      });
      
      if (data.success) {
        setMessage('Profile saved successfully!');
        setUser({
          ...user,
          profilePicUrl: urlToSave,
          email: form.email,
          phone: form.phone,
          address: form.address,
          eventColor: form.eventColor,
          gender: form.gender
        });
      } else {
        setMessage(data.message || 'Failed to save profile.');
        setForm({ ...form, profilePicUrl: user.profilePicUrl || DEFAULT_PROFILE_PIC });
      }
    } catch (err) {
      setMessage('Error saving profile. Please try again.');
      console.error('Error saving profile:', err);
      setForm({ ...form, profilePicUrl: user.profilePicUrl || DEFAULT_PROFILE_PIC });
    }
  };
  
  const handlePasswordChange = async () => {
    setPasswordMessage('');
    
    if (!form.currentPassword || !form.newPassword || !form.confirmNewPassword) {
      return setPasswordMessage('All password fields are required.');
    }
    
    if (form.newPassword !== form.confirmNewPassword) {
      return setPasswordMessage('Passwords do not match.');
    }
    
    if (form.newPassword.length < 6) {
      return setPasswordMessage('Password must be at least 6 characters.');
    }
    
    setPasswordMessage('Changing password...');
    
    try {
      const { data } = await axios.post(`${API_BASE}/update-password`, {
        username: user.username,
        currentPassword: form.currentPassword,
        newPassword: form.newPassword
      });
      
      setPasswordMessage(data.success ? 'Password updated successfully!' : data.message || 'Failed to update password.');
      
      if (data.success) {
        setForm({ ...form, currentPassword: '', newPassword: '', confirmNewPassword: '' });
      }
    } catch (err) {
      setPasswordMessage('Error updating password.');
      console.error('Error updating password:', err);
    }
  };
  
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex justify-between mb-6">
        <Button 
          className="btn-secondary" 
          onClick={() => setPage('menu')}
        >
          Back to Menu
        </Button>
        <Button 
          className="btn-danger" 
          onClick={onLogout}
        >
          Sign Out
        </Button>
      </div>
      <div className="card p-8">
        <h1 className="text-2xl font-semibold text-white mb-6">Profile Settings</h1>
        <div className="space-y-6">
          <div>
            <label className="form-label">Profile Picture</label>
            <div className="flex items-center gap-4 mb-4">
              <div className="profile-pic-container">
                <img 
                  src={form.profilePicUrl || DEFAULT_PROFILE_PIC} 
                  alt="Profile" 
                  className="profile-pic" 
                />
              </div>
              <span className="text-white">{user.username}</span>
            </div>
            <Input 
              type="file" 
              accept="image/*" 
              onChange={handleFileChange} 
              className="file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-teal-500 file:text-white hover:file:bg-teal-600" 
            />
          </div>
          
          <Input 
            label="Email" 
            type="email" 
            name="email" 
            placeholder="Enter your email" 
            value={form.email} 
            onChange={handleChange} 
          />
          
          <Input 
            label="Phone Number" 
            type="tel" 
            name="phone" 
            placeholder="Enter your phone number" 
            value={form.phone} 
            onChange={handleChange} 
          />
          
          <Select
            label="Gender"
            name="gender"
            value={form.gender}
            onChange={handleChange}
            options={[
              { value: '', label: 'Select Gender' }, 
              { value: 'Male', label: 'Male' }, 
              { value: 'Female', label: 'Female' }
            ]}
          />
          
          <div>
            <label className="form-label">Address</label>
            <textarea 
              name="address" 
              placeholder="Enter your address" 
              value={form.address} 
              onChange={handleChange} 
              rows="3" 
              className="form-input"
            ></textarea>
          </div>
          
          <Input 
            label="Event Color" 
            type="color" 
            name="eventColor" 
            value={form.eventColor} 
            onChange={handleChange} 
            className="h-12 cursor-pointer" 
          />
          
          {message && (
            <p className={`text-center text-sm ${message.includes('success') ? 'text-green-400' : 'text-red-400'}`}>
              {message}
            </p>
          )}
          
          <Button onClick={handleSaveProfile}>Save Profile</Button>
          
          <div className="pt-6 border-t border-white/10">
            <h2 className="text-xl font-semibold text-white mb-4">Change Password</h2>
            <Input 
              type="password" 
              placeholder="Current Password" 
              name="currentPassword" 
              value={form.currentPassword} 
              onChange={handleChange} 
              className="mb-4" 
            />
            
            <Input 
              type="password" 
              placeholder="New Password" 
              name="newPassword" 
              value={form.newPassword} 
              onChange={handleChange} 
              className="mb-4" 
            />
            
            <Input 
              type="password" 
              placeholder="Confirm New Password" 
              name="confirmNewPassword" 
              value={form.confirmNewPassword} 
              onChange={handleChange} 
              className="mb-4" 
            />
            
            {passwordMessage && (
              <p className={`text-center text-sm ${passwordMessage.includes('success') ? 'text-green-400' : 'text-red-400'}`}>
                {passwordMessage}
              </p>
            )}
            
            <Button onClick={handlePasswordChange}>Change Password</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;