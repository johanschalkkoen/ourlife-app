import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE, DEFAULT_PROFILE_PIC, formatAmount, formatDateTime, getCurrentDateTime, capitalize } from '../utils/helpers';
import { Input, Button, Select, ProfilePic } from './ui/FormElements';
import useAccessibleUsers from '../hooks/useAccessibleUsers';
import { MONTHS } from '../utils/helpers';

const Financial = ({ user, setPage, onLogout }) => {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({
    description: '',
    amount: '',
    type: 'income',
    date: getCurrentDateTime()
  });
  const [hideValues, setHideValues] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState('07');
  const [netTotal, setNetTotal] = useState(0);
  const [bulkData, setBulkData] = useState('');
  const [importMessage, setImportMessage] = useState('');
  const [showAddItemForm, setShowAddItemForm] = useState(false);
  const [showImportTool, setShowImportTool] = useState(false);
  const [userProfiles, setUserProfiles] = useState({
    [user.username]: user.profilePicUrl
  });
  
  const {
    targetUsers,
    showTargetUsers,
    setShowTargetUsers,
    error
  } = useAccessibleUsers(user, profiles => setUserProfiles(profiles));
  
  const fetchItems = () => {
    console.log('Financial: fetchItems called, showTargetUsers:', showTargetUsers, 'targetUsers:', targetUsers);
    const usersToFetch = [user.username, ...(showTargetUsers ? targetUsers : [])];
    console.log('Financial: Fetching data for users:', usersToFetch);
    
    Promise.all(usersToFetch.map(u => 
      axios.get(`${API_BASE}/financial`, { params: { user: u } })
        .then(({ data }) => {
          console.log(`Financial: Data fetched for ${u}:`, data);
          return data;
        })
        .catch(err => {
          console.error(`Financial: Error fetching data for ${u}:`, err);
          return [];
        })
    )).then(results => {
      const flatItems = results.flat();
      console.log('Financial: Combined items:', flatItems);
      setItems(flatItems);
    });
  };
  
  const calculateNetTotal = () => {
    const usersToShow = [user.username, ...(showTargetUsers ? targetUsers : [])];
    console.log('Financial: Calculating net total for users:', usersToShow, 'month:', selectedMonth);
    const total = items
      .filter(item => usersToShow.includes(item.user) && item.date.startsWith(`2025-${selectedMonth}`))
      .reduce((sum, item) => item.type === 'income' ? sum + item.amount : sum - item.amount, 0);
    console.log('Financial: Net total:', total);
    setNetTotal(total);
  };
  
  const addItem = async () => {
    if (!form.description || !form.amount || !form.date) return;
    const item = {
      user: user.username,
      description: form.description,
      amount: parseFloat(form.amount),
      type: form.type,
      date: form.date
    };
    
    try {
      await Promise.all([
        axios.post(`${API_BASE}/financial`, item),
        axios.post(`${API_BASE}/calendar`, {
          ...item,
          title: `${form.description} (${form.type})`,
          financial: true,
          eventColor: user.eventColor
        })
      ]);
      fetchItems();
      setForm({
        description: '',
        amount: '',
        type: 'income',
        date: getCurrentDateTime()
      });
      setShowAddItemForm(false);
    } catch (err) {
      console.error('Financial: Error adding item:', err);
    }
  };
  
  const deleteItem = id => 
    axios.delete(`${API_BASE}/financial/${id}`)
      .then(fetchItems)
      .catch(err => console.error('Financial: Error deleting item:', err));
  
  const handleBulkImport = async () => {
    if (!bulkData.trim()) return setImportMessage('Please paste data into the text box.');
    
    const itemsToImport = bulkData
      .trim()
      .split('\n')
      .filter(line => line.trim())
      .map(line => {
        const [description, amount, type, date] = line.split(',').map(field => field.trim());
        if (!description || !amount || !type || !date) return null;
        return {
          user: user.username,
          description,
          amount: parseFloat(amount),
          type,
          date
        };
      })
      .filter(Boolean);
    
    if (!itemsToImport.length) return setImportMessage('No valid data found. Please check the format.');
    
    setImportMessage(`Importing ${itemsToImport.length} items...`);
    
    try {
      await Promise.all(itemsToImport.map(item => Promise.all([
        axios.post(`${API_BASE}/financial`, item),
        axios.post(`${API_BASE}/calendar`, {
          ...item,
          title: `${item.description} (${item.type})`,
          financial: true,
          eventColor: user.eventColor
        })
      ])));
      setImportMessage(`Successfully imported ${itemsToImport.length} items!`);
      setBulkData('');
      setShowImportTool(false);
      fetchItems();
    } catch (err) {
      setImportMessage('An error occurred during import. Please check the data and try again.');
      console.error('Financial: Bulk import error:', err);
    }
  };
  
  const toggleButtonLabel = targetUsers.length === 1
    ? `Show/Hide ${capitalize(targetUsers[0])}'s Data`
    : `Show/Hide Accessible Users' Data`;
  
  // Fetch items when dependencies change
  useEffect(() => {
    fetchItems();
  }, [showTargetUsers, targetUsers, user.username]);
  
  // Calculate net total when items or filters change
  useEffect(() => {
    calculateNetTotal();
  }, [items, showTargetUsers, selectedMonth]);
  
  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <div className="responsive-button-group mb-6">
        <Button className="btn-secondary" onClick={() => setPage('menu')}>
          Back to Menu
        </Button>
        <Button className="btn-danger" onClick={onLogout}>
          Sign Out
        </Button>
      </div>
      <div className="card responsive-card-content">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-white flex items-center gap-3 mb-4 sm:mb-0">
            <ProfilePic src={user.profilePicUrl} username={user.username} />
            <span>Finances</span>
          </h1>
          <div className="responsive-button-group w-full sm:w-auto">
            <Select 
              options={MONTHS.map(m => ({ ...m, label: `${m.label} 2025` }))} 
              value={selectedMonth} 
              onChange={e => setSelectedMonth(e.target.value)} 
              className="mb-2 sm:mb-0"
            />
            <Button 
              className="btn-info" 
              onClick={() => setShowAddItemForm(!showAddItemForm)}
            >
              {showAddItemForm ? 'Hide Form' : 'Add Item'}
            </Button>
            <Button 
              className="btn-success" 
              onClick={() => setShowImportTool(!showImportTool)}
            >
              {showImportTool ? 'Hide Import' : 'Bulk Import'}
            </Button>
          </div>
        </div>
        
        {error && <p className="error-message">{error}</p>}
        
        {targetUsers.length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-medium text-white mb-3">View Data:</h3>
            <div className="flex flex-wrap gap-2">
              <button 
                className={`toggle-button ${showTargetUsers ? 'active' : 'inactive'}`} 
                onClick={() => setShowTargetUsers(!showTargetUsers)}
              >
                {toggleButtonLabel}
              </button>
            </div>
          </div>
        )}
        
        <div className="card p-4 sm:p-6 mb-6">
          <h2 className="text-xl font-semibold text-white mb-2">
            Net Total for {MONTHS.find(m => m.value === selectedMonth)?.label} 2025
          </h2>
          <p className={`text-2xl font-bold ${netTotal >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {hideValues ? '****' : formatAmount(netTotal)}
          </p>
        </div>
        
        {showImportTool && (
          <div className="card p-4 sm:p-6 mb-6 space-y-4">
            <h2 className="text-xl font-semibold text-white">Bulk Import Tool</h2>
            <p className="text-gray-300 text-sm">
              Paste your data here in CSV format: Description,Amount,Type,Date (YYYY-MM-DD HH:mm:ss)
            </p>
            <textarea 
              placeholder="e.g., Salary,50000,income,2025-07-25 14:30:00" 
              value={bulkData} 
              onChange={e => setBulkData(e.target.value)} 
              rows="8" 
              className="form-input"
            />
            <Button className="btn-success" onClick={handleBulkImport}>
              Import Pasted Data
            </Button>
            {importMessage && (
              <p className={`text-center text-sm ${importMessage.includes('success') ? 'text-green-400' : 'text-red-400'}`}>
                {importMessage}
              </p>
            )}
          </div>
        )}
        
        {showAddItemForm && (
          <div className="card p-4 sm:p-6 mb-6 space-y-4">
            <h2 className="text-xl font-semibold text-white">Add Financial Item</h2>
            <Input 
              name="description" 
              placeholder="Description" 
              value={form.description} 
              onChange={e => setForm({ ...form, description: e.target.value })} 
            />
            <Input 
              type="number" 
              name="amount" 
              placeholder="Amount (in ZAR)" 
              value={form.amount} 
              onChange={e => setForm({ ...form, amount: e.target.value })} 
            />
            <Select 
              name="type" 
              value={form.type} 
              onChange={e => setForm({ ...form, type: e.target.value })} 
              options={[
                { value: 'income', label: 'Income' }, 
                { value: 'expense', label: 'Expense' }
              ]} 
            />
            <Input 
              type="datetime-local" 
              name="date" 
              value={form.date} 
              onChange={e => setForm({ ...form, date: e.target.value })} 
              step="1" 
            />
            <Button onClick={addItem}>Add Item</Button>
          </div>
        )}
        
        <div className="space-y-4 mb-6">
          <Button onClick={() => setHideValues(!hideValues)}>
            {hideValues ? 'Show Values' : 'Hide Values'}
          </Button>
        </div>
        
        <div className="space-y-3">
          {items
            .filter(item => 
              [user.username, ...(showTargetUsers ? targetUsers : [])].includes(item.user) && 
              item.date.startsWith(`2025-${selectedMonth}`)
            )
            .map(item => (
              <div key={item.id} className="responsive-financial-item">
                <div className="responsive-financial-item-content">
                  <div className="event-profile-pic-container">
                    <img 
                      src={userProfiles[item.user] || DEFAULT_PROFILE_PIC} 
                      alt={item.user} 
                      className="event-profile-pic" 
                    />
                  </div>
                  <span className="text-sm sm:text-base">
                    {item.description} ({item.type}) - {formatDateTime(item.date)} ({item.user})
                  </span>
                </div>
                <div className="responsive-financial-item-actions">
                  <span className="font-medium">{hideValues ? '****' : formatAmount(item.amount)}</span>
                  {item.user === user.username && (
                    <Button className="px-3 py-1 btn-danger" onClick={() => deleteItem(item.id)}>
                      Delete
                    </Button>
                  )}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Financial;