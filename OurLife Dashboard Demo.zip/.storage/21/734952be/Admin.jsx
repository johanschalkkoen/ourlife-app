import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE } from '../utils/helpers';
import { Input, Button, Select, ProfilePic } from './ui/FormElements';

const Admin = ({ user, setPage, onLogout }) => {
  const [users, setUsers] = useState([]);
  const [accessList, setAccessList] = useState([]);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [viewer, setViewer] = useState('');
  const [target, setTarget] = useState('');
  const [passwordUsername, setPasswordUsername] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [message, setMessage] = useState('');

  const fetchUsers = async () => {
    if (!user?.username) {
      console.error('fetchUsers: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    console.log('Fetching users with adminUsername:', user.username);
    
    try {
      const { data } = await axios.get(`${API_BASE}/users`, {
        params: { adminUsername: user.username }
      });
      
      data.success
        ? setUsers(data.data)
        : setMessage(data.message || 'Failed to fetch users.');
    } catch (error) {
      console.error('Error fetching users:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error fetching users.');
    }
  };

  const fetchAccessList = async () => {
    if (!user?.username) {
      console.error('fetchAccessList: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    console.log('Fetching access list with adminUsername:', user.username);
    
    try {
      const { data } = await axios.get(`${API_BASE}/get-access`, {
        params: { adminUsername: user.username }
      });
      
      data.success
        ? setAccessList(data.accessList)
        : setMessage(data.message || 'Failed to fetch access list.');
    } catch (error) {
      console.error('Error fetching access list:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error fetching access list.');
    }
  };

  const handleAddUser = async () => {
    if (!user?.username) {
      console.error('handleAddUser: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    if (!newUsername || !newPassword) {
      setMessage('Username and password are required.');
      return;
    }
    
    console.log('Adding user:', { newUsername, adminUsername: user.username });
    
    try {
      const { data } = await axios.post(`${API_BASE}/add-user`, {
        username: newUsername,
        password: newPassword,
        adminUsername: user.username
      });
      
      if (data.success) {
        setMessage('User added successfully!');
        setNewUsername('');
        setNewPassword('');
        fetchUsers();
      } else {
        setMessage(data.message || 'Failed to add user.');
      }
    } catch (error) {
      console.error('Error adding user:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error adding user.');
    }
  };

  const handleDeleteUser = async (username) => {
    if (!user?.username) {
      console.error('handleDeleteUser: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    console.log('Deleting user:', { username, adminUsername: user.username });
    
    try {
      const { data } = await axios.delete(`${API_BASE}/delete-user/${username}`, {
        data: { adminUsername: user.username }
      });
      
      if (data.success) {
        setMessage('User deleted successfully!');
        fetchUsers();
        fetchAccessList();
      } else {
        setMessage(data.message || 'Failed to delete user.');
      }
    } catch (error) {
      console.error('Error deleting user:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error deleting user.');
    }
  };

  const handleGrantAdmin = async (username) => {
    if (!user?.username) {
      console.error('handleGrantAdmin: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    console.log('Granting admin for:', { username, adminUsername: user.username });
    
    try {
      const { data } = await axios.post(`${API_BASE}/grant-admin`, {
        username,
        adminUsername: user.username
      });
      
      if (data.success) {
        setMessage(`Admin access granted for ${username}!`);
        fetchUsers();
      } else {
        setMessage(data.message || 'Failed to grant admin access.');
      }
    } catch (error) {
      console.error('Error granting admin access:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error granting admin access.');
    }
  };

  const handleRevokeAdmin = async (username) => {
    if (!user?.username) {
      console.error('handleRevokeAdmin: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    console.log('Revoking admin for:', { username, adminUsername: user.username });
    
    try {
      const { data } = await axios.post(`${API_BASE}/revoke-admin`, {
        username,
        adminUsername: user.username
      });
      
      if (data.success) {
        setMessage(`Admin access revoked for ${username}!`);
        fetchUsers();
      } else {
        setMessage(data.message || 'Failed to revoke admin access.');
      }
    } catch (error) {
      console.error('Error revoking admin access:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error revoking admin access.');
    }
  };

  const handleGrantAccess = async () => {
    if (!user?.username) {
      console.error('handleGrantAccess: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    if (!viewer || !target) {
      setMessage('Viewer and target usernames are required.');
      return;
    }
    
    console.log('Granting access:', { viewer, target, adminUsername: user.username });
    
    try {
      const { data } = await axios.post(`${API_BASE}/grant-access`, {
        viewer,
        target,
        adminUsername: user.username
      });
      
      if (data.success) {
        setMessage(`Access granted for ${viewer} to view ${target}'s data.`);
        setViewer('');
        setTarget('');
        fetchAccessList();
      } else {
        setMessage(data.message || 'Failed to grant access.');
      }
    } catch (error) {
      console.error('Error granting access:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error granting access.');
    }
  };

  const handleRevokeAccess = async (viewer, target) => {
    if (!user?.username) {
      console.error('handleRevokeAccess: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    console.log('Revoking access:', { viewer, target, adminUsername: user.username });
    
    try {
      const { data } = await axios.post(`${API_BASE}/revoke-access`, {
        viewer,
        target,
        adminUsername: user.username
      });
      
      if (data.success) {
        setMessage(`Access revoked for ${viewer} to view ${target}'s data.`);
        fetchAccessList();
      } else {
        setMessage(data.message || 'Failed to revoke access.');
      }
    } catch (error) {
      console.error('Error revoking access:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error revoking access.');
    }
  };

  const handleUpdatePassword = async () => {
    if (!user?.username) {
      console.error('handleUpdatePassword: User not initialized or username missing');
      setMessage('User not logged in');
      return;
    }
    
    if (!passwordUsername || !newUserPassword) {
      setMessage('Username and new password are required.');
      return;
    }
    
    console.log('Updating password for:', { passwordUsername, adminUsername: user.username });
    
    try {
      const { data } = await axios.post(`${API_BASE}/admin-update-password`, {
        username: passwordUsername,
        newPassword: newUserPassword,
        adminUsername: user.username
      });
      
      if (data.success) {
        setMessage(`Password updated for ${passwordUsername}!`);
        setPasswordUsername('');
        setNewUserPassword('');
      } else {
        setMessage(data.message || 'Failed to update password.');
      }
    } catch (error) {
      console.error('Error updating password:', error.response?.data || error);
      setMessage(error.response?.data?.message || 'Error updating password.');
    }
  };

  useEffect(() => {
    if (user?.isAdmin) {
      console.log('User is admin, fetching users and access list');
      fetchUsers();
      fetchAccessList();
    }
  }, [user]);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex justify-between mb-6">
        <Button className="btn-secondary" onClick={() => setPage('menu')}>
          Back to Menu
        </Button>
        <Button className="btn-danger" onClick={onLogout}>
          Sign Out
        </Button>
      </div>
      <div className="card p-8">
        <h1 className="text-2xl font-semibold text-white mb-6 flex items-center gap-3">
          <ProfilePic src={user.profilePicUrl} username={user.username} />
          <span>Admin Dashboard</span>
        </h1>
        
        {message && (
          <p className={`text-center text-sm ${message.includes('success') ? 'text-green-400' : 'text-red-400'} mb-6`}>
            {message}
          </p>
        )}
        
        <div className="space-y-8">
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Add New User</h2>
            <Input
              label="Username"
              placeholder="Enter username"
              value={newUsername}
              onChange={e => setNewUsername(e.target.value)}
            />
            <Input
              label="Password"
              type="password"
              placeholder="Enter password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              className="mt-4"
            />
            <Button
              className="mt-4 btn-success"
              onClick={handleAddUser}
            >
              Add User
            </Button>
          </div>
          
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Update User Password</h2>
            <Select
              label="Select User"
              value={passwordUsername}
              onChange={e => setPasswordUsername(e.target.value)}
              options={users.map(u => ({ value: u.username, label: u.username }))}
            />
            <Input
              label="New Password"
              type="password"
              placeholder="Enter new password"
              value={newUserPassword}
              onChange={e => setNewUserPassword(e.target.value)}
              className="mt-4"
            />
            <Button
              className="mt-4 btn-warning"
              onClick={handleUpdatePassword}
            >
              Update Password
            </Button>
          </div>
          
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Users</h2>
            <div className="space-y-3">
              {users.map(u => (
                <div key={u.username} className="flex justify-between items-center p-4 card">
                  <span>{u.username} {u.isAdmin ? '(Admin)' : ''}</span>
                  <div className="flex space-x-2">
                    <Button
                      className="px-3 py-1 btn-danger"
                      onClick={() => handleDeleteUser(u.username)}
                      disabled={u.username === user.username}
                    >
                      Delete
                    </Button>
                    {u.isAdmin ? (
                      <Button
                        className="px-3 py-1 btn-warning"
                        onClick={() => handleRevokeAdmin(u.username)}
                        disabled={u.username === user.username}
                      >
                        Revoke Admin
                      </Button>
                    ) : (
                      <Button
                        className="px-3 py-1 btn-success"
                        onClick={() => handleGrantAdmin(u.username)}
                        disabled={u.username === user.username}
                      >
                        Grant Admin
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Grant Access</h2>
            <Select
              label="Viewer"
              value={viewer}
              onChange={e => setViewer(e.target.value)}
              options={users.map(u => ({ value: u.username, label: u.username }))}
            />
            <Select
              label="Target"
              value={target}
              onChange={e => setTarget(e.target.value)}
              options={users.map(u => ({ value: u.username, label: u.username }))}
              className="mt-4"
            />
            <Button
              className="mt-4 btn-info"
              onClick={handleGrantAccess}
            >
              Grant Access
            </Button>
          </div>
          
          <div className="card p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Access List</h2>
            <div className="space-y-3">
              {accessList.map(access => (
                <div
                  key={`${access.viewer}-${access.target}`}
                  className="flex justify-between items-center p-4 card"
                >
                  <span>{access.viewer} can view {access.target}'s data</span>
                  <Button
                    className="px-3 py-1 btn-danger"
                    onClick={() => handleRevokeAccess(access.viewer, access.target)}
                  >
                    Revoke
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;